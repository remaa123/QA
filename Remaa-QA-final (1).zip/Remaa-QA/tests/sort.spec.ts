import { test } from '@playwright/test';
import { SortPage } from '../pages/SortPage';

test.describe('Sort Feature', () => {
    let sortPage: SortPage;

    test.beforeEach(async ({ page }) => {
        sortPage = new SortPage(page);
        await sortPage.gotoHome();
    });

    test('User should sort products from A to Z', async () => {
        await sortPage.sortByNameAZ();
        await sortPage.expectProductsSortedByNameAZ();
    });

    test('User should sort products by price from high to low', async () => {
        await sortPage.sortByPriceHighToLow();
        await sortPage.expectProductsSortedByPriceHighToLow();
    });
});
