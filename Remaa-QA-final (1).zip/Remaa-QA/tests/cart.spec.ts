import { test } from '@playwright/test';
import { CartPage } from '../pages/CartPage';

test.describe('Cart Feature', () => {
    let cartPage: CartPage;

    test.beforeEach(async ({ page }) => {
        cartPage = new CartPage(page);
        await cartPage.gotoHome();
    });

    test('User should add product to cart successfully', async () => {
        await cartPage.addProductToCart();
        await cartPage.verifyProductAdded();
    });

    test('User should remove product from cart successfully', async () => {
        await cartPage.addProductToCart();
        await cartPage.verifyProductAdded();
        await cartPage.openCart();
        await cartPage.removeProductFromCart();
        await cartPage.verifyProductDeleted();
    });
});
