import { test } from '@playwright/test';
import { RegisterPage } from '../pages/RegisterPage';
import { LoginPage } from '../pages/LoginPage';
import { invalidLoginCases, loginData } from '../utils/testData';

test.describe('Login Feature', () => {
    let user = loginData;

    test.beforeAll(async ({ browser }, testInfo) => {
        user = {
            ...loginData,
            email: `login-${Date.now()}-${testInfo.project.name}@example.com`,
        };

        const page = await browser.newPage();
        const registerPage = new RegisterPage(page);

        await registerPage.goto();
        await registerPage.register(user);
        await registerPage.expectRegistrationCompleted();
        await page.close();
    });

    test('User should login successfully with valid credentials', async ({ page }) => {
        const loginPage = new LoginPage(page);

        await loginPage.goto();
        await loginPage.login(user.email, user.password);
        await loginPage.expectLoggedIn();
    });

    for (const invalidCase of invalidLoginCases) {
        test(`User should not login with ${invalidCase.title}`, async ({ page }) => {
            const loginPage = new LoginPage(page);

            await loginPage.goto();
            await loginPage.login(invalidCase.email, invalidCase.password);
            await loginPage.expectLoginFailed();
        });
    }
});
