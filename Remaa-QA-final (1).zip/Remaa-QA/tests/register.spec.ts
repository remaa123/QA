import { test } from '@playwright/test';
import { RegisterPage } from '../pages/RegisterPage';
import { registerData } from '../utils/testData';

test.describe('Register Feature', () => {
    test('User should register successfully with valid data', async ({ page }, testInfo) => {
        const user = {
            ...registerData,
            email: `register-${Date.now()}-${testInfo.project.name}@example.com`,
        };

        const registerPage = new RegisterPage(page);

        await registerPage.goto();
        await registerPage.register(user);
        await registerPage.expectRegistrationCompleted();
    });
});
