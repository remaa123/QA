import { Page, expect } from '@playwright/test';

export class CartPage {
    constructor(private page: Page) { }

    async gotoHome() {
        await this.page.goto('/');
        await expect(this.page.locator('[data-test="sort"]')).toBeVisible();
        await expect(this.page.locator('a[data-test^="product-"]').first()).toBeVisible();
    }

    async addProductToCart() {
        await this.page.locator('a[data-test^="product-"]').first().click();
        await expect(this.page.locator('[data-test="add-to-cart"]')).toBeEnabled();
        await this.page.locator('[data-test="add-to-cart"]').click();
    }

    async verifyProductAdded() {
        await expect(this.page.getByRole('alert').filter({ hasText: /Product added/i })).toBeVisible();
        await expect(this.page.locator('[data-test="cart-quantity"]')).toHaveText('1');
    }

    async openCart() {
        await this.page.locator('[data-test="nav-cart"]').click();
        await expect(this.page).toHaveURL(/\/checkout/);
        await expect(this.page.locator('[data-test="product-title"]')).toBeVisible();
    }

    async removeProductFromCart() {
        await this.page.locator('[data-test="delete-product"], .btn.btn-danger').first().click();
    }

    async verifyProductDeleted() {
        await expect(this.page.getByRole('alert').filter({ hasText: /Product deleted/i })).toBeVisible();
        await expect(this.page.locator('[data-test="product-title"]')).toHaveCount(0);
    }
}
