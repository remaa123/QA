import { expect, Locator, Page } from '@playwright/test';

export class SortPage {
    constructor(private page: Page) { }

    async gotoHome() {
        await this.page.goto('/');
        await expect(this.page.locator('[data-test="sort"]')).toBeVisible();
        await expect(this.page.locator('a[data-test^="product-"]').first()).toBeVisible();
    }

    async sortByNameAZ() {
        await this.page.locator('[data-test="sort"]').selectOption('name,asc');
        await this.page.waitForLoadState('networkidle');
    }

    async sortByPriceHighToLow() {
        await this.page.locator('[data-test="sort"]').selectOption('price,desc');
        await this.page.waitForLoadState('networkidle');
    }

    private async firstVisibleLocator(selectors: string[]): Promise<Locator> {
        for (const selector of selectors) {
            const locator = this.page.locator(selector);
            if (await locator.count() > 0) {
                return locator;
            }
        }
        throw new Error(`No matching locator found. Tried: ${selectors.join(', ')}`);
    }

    async productNames(): Promise<string[]> {
        const locator = await this.firstVisibleLocator([
            '[data-test="product-name"]',
            '.card-title',
            'a[data-test^="product-"] .card-title',
        ]);

        const names = await locator.allTextContents();
        return names.map(name => name.trim()).filter(Boolean);
    }

    async productPrices(): Promise<number[]> {
        const locator = await this.firstVisibleLocator([
            '[data-test="product-price"]',
            '.card-footer .float-end',
            '.card .price',
        ]);

        const prices = await locator.allTextContents();
        return prices
            .map(price => Number(price.replace(/[^0-9.]/g, '')))
            .filter(price => !Number.isNaN(price));
    }

    async expectProductsSortedByNameAZ() {
        const names = await this.productNames();
        expect(names.length).toBeGreaterThan(0);

        const expected = [...names].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }));
        expect(names).toEqual(expected);
    }

    async expectProductsSortedByPriceHighToLow() {
        const prices = await this.productPrices();
        expect(prices.length).toBeGreaterThan(0);

        const expected = [...prices].sort((a, b) => b - a);
        expect(prices).toEqual(expected);
    }
}
