import { expect, Page } from '@playwright/test';

export class LoginPage {
    constructor(private page: Page) { }

    async goto() {
        await this.page.goto('/auth/login');
        await expect(this.page.locator('[data-test="email"]')).toBeVisible();
    }

    async login(email: string, password: string) {
        await this.page.locator('[data-test="email"]').fill(email);
        await this.page.locator('[data-test="password"]').fill(password);
        await this.page.locator('[data-test="login-submit"]').click();
    }

    async expectLoggedIn() {
        await expect(this.page).toHaveURL(/\/account$/);
        await expect(this.page.locator('[data-test="nav-menu"]')).toBeVisible();
    }

    async expectLoginFailed() {
        await expect(this.page).toHaveURL(/\/auth\/login/);
        await expect(
            this.page.locator('[data-test="login-error"], .alert-danger, .invalid-feedback').first()
        ).toBeVisible();
    }
}
