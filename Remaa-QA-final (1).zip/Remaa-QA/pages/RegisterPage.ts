import { expect, Page } from '@playwright/test';
import { UserData } from '../utils/testData';

export class RegisterPage {
    constructor(private page: Page) { }

    async goto() {
        await this.page.goto('/auth/register');
        await expect(this.page.locator('[data-test="register-form"]')).toBeVisible();
    }

    async register(userData: UserData) {
        await this.page.locator('[data-test="first-name"]').fill(userData.firstName);
        await this.page.locator('[data-test="last-name"]').fill(userData.lastName);
        await this.page.locator('[data-test="dob"]').fill(userData.dob);
        await this.page.locator('[data-test="country"]').selectOption(userData.country);
        await this.page.locator('[data-test="postal_code"]').fill(userData.postalCode);
        await this.page.locator('[data-test="house_number"]').fill(userData.houseNumber);
        await this.page.locator('[data-test="street"]').fill(userData.street);
        await this.page.locator('[data-test="city"]').fill(userData.city);
        await this.page.locator('[data-test="state"]').fill(userData.state);
        await this.page.locator('[data-test="phone"]').fill(userData.phone);
        await this.page.locator('[data-test="email"]').fill(userData.email);
        await this.page.locator('[data-test="password"]').fill(userData.password);
        await this.page.locator('[data-test="register-submit"]').click();
    }

    async expectRegistrationCompleted() {
        await expect(this.page).toHaveURL(/\/auth\/login$/, { timeout: 20_000 });
    }
}
