# QA Homework 3 - Playwright TypeScript Framework

This project tests the Practice Software Testing website using Playwright and TypeScript.

## Covered features

- Register
- Login
- Add to cart
- Remove from cart
- Sort from A to Z
- Sort by price from high to low

## Concepts used

- Playwright with TypeScript
- Page Object Model (POM)
- Hooks: `beforeEach`, `beforeAll`
- Parameterized tests for invalid login cases
- Environment variables using `.env`
- Two browsers: Chromium and Firefox
- HTML report, screenshots, and videos on failure

## How to run

```bash
npm install
copy .env.example .env
npx playwright install
npm test
npm run report
```

On Git Bash, you may use:

```bash
cp .env.example .env
```

## Useful commands

```bash
npm run test:chromium
npm run test:firefox
npm run test:headed
npm run codegen
```
