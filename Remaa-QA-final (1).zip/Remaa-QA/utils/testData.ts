export type UserData = {
    firstName: string;
    lastName: string;
    dob: string;
    country: string;
    postalCode: string;
    houseNumber: string;
    street: string;
    city: string;
    state: string;
    phone: string;
    email: string;
    password: string;
};

export const defaultPassword = process.env.TEST_PASSWORD ?? 'Remaa@2005Test!';

export const registerData: UserData = {
    firstName: 'Remaa',
    lastName: 'Saleh',
    dob: '2000-07-02',
    country: 'PS',
    postalCode: '12345',
    houseNumber: '10',
    street: 'Al-Najah Street',
    city: 'Nablus',
    state: 'Nablus',
    phone: '0597816993',
    email: 'remaa.test@example.com',
    password: defaultPassword,
};

export const loginData: UserData = {
    ...registerData,
    email: 'remaa.login@example.com',
};

export const invalidLoginCases = [
    {
        title: 'invalid email and password',
        email: 'wrong-user@example.com',
        password: 'WrongPassword123!',
    },
    {
        title: 'invalid email format',
        email: 'not-an-email',
        password: 'WrongPassword123!',
    },
];
