package main.najah.test;

import main.najah.code.Calculator;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.api.parallel.ExecutionMode;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("TestCalculator - JUnit 5 tests for Calculator")
@TestMethodOrder(OrderAnnotation.class)
class TestCalculator {

    private Calculator calculator;

    @BeforeAll
    static void beforeAll() {
        System.out.println("BeforeAll: Calculator test class setup complete");
    }

    @AfterAll
    static void afterAll() {
        System.out.println("AfterAll: Calculator test class finished");
    }

    @BeforeEach
    void setUp() {
        calculator = new Calculator();
        System.out.println("BeforeEach: New Calculator object created");
    }

    @AfterEach
    void tearDown() {
        System.out.println("AfterEach: Calculator test finished");
    }

    @Test
    @Order(1)
    @DisplayName("add should return correct sum for valid integers")
    void testAddValidNumbers() {
        int result = calculator.add(1, 2, 3, 4);

        assertAll("Check addition result",
                () -> assertEquals(10, result),
                () -> assertNotEquals(9, result)
        );
    }

    @Test
    @Order(2)
    @DisplayName("add should return 0 when no numbers are provided")
    void testAddNoNumbers() {
        int result = calculator.add();

        assertAll("Check empty varargs addition",
                () -> assertEquals(0, result),
                () -> assertTrue(result >= 0)
        );
    }

    @ParameterizedTest(name = "factorial({0}) should be valid and positive")
    @ValueSource(ints = {0, 1, 3, 5})
    @Order(3)
    @DisplayName("factorial should return correct values for valid input")
    void testFactorialParameterized(int n) {
        int result = calculator.factorial(n);

        if (n == 0 || n == 1) {
            assertEquals(1, result);
        } else if (n == 3) {
            assertEquals(6, result);
        } else if (n == 5) {
            assertEquals(120, result);
        }

        assertTrue(result > 0 || n == 0);
    }

    @Test
    @Order(4)
    @DisplayName("factorial should throw exception for negative input")
    void testFactorialNegativeInput() {
        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> calculator.factorial(-1)
        );

        assertEquals("Negative input", ex.getMessage());
    }

    @ParameterizedTest(name = "{0} / {1} = {2}")
    @CsvSource({
            "10, 2, 5",
            "9, 3, 3",
            "7, 2, 3"
    })
    @Order(5)
    @DisplayName("divide should return correct quotient for valid inputs")
    void testDivideParameterized(int a, int b, int expected) {
        int result = calculator.divide(a, b);

        assertAll("Check division result",
                () -> assertEquals(expected, result),
                () -> assertNotNull(result)
        );
    }

    @Test
    @Order(6)
    @DisplayName("divide should throw ArithmeticException when divisor is zero")
    void testDivideByZero() {
        ArithmeticException ex = assertThrows(
                ArithmeticException.class,
                () -> calculator.divide(10, 0)
        );

        assertEquals("Cannot divide by zero", ex.getMessage());
    }

    @Test
    @Order(7)
    @DisplayName("Calculator operations should finish within timeout")
    void testTimeout() {
        assertTimeout(Duration.ofMillis(200), () -> {
            calculator.add(1, 2, 3, 4, 5);
            calculator.factorial(8);
            calculator.divide(100, 5);
        });
    }

    @Test
    @Disabled("Intentional failing test. Fix by changing expected result from 100 to 6.")
    @Order(8)
    @DisplayName("Intentional failing test example")
    void testIntentionalFailure() {
        assertEquals(100, calculator.add(1, 2, 3));
    }
}