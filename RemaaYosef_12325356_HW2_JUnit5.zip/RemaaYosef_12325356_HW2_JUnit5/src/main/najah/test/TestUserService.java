package main.najah.test;

import main.najah.code.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("TestUserService - JUnit 5 tests for UserService")
class TestUserService {

    private UserService userService;

    @BeforeEach
    void setUp() {
        userService = new UserService();
    }

    @ParameterizedTest(name = "email \"{0}\" validity should be {1}")
    @CsvSource({
            "admin@test.com, true",
            "user.name@domain.org, true",
            "invalidemail, false",
            "missingdot@test, false",
            "'', false"
    })
    @DisplayName("isValidEmail should correctly validate different email formats")
    void testIsValidEmailParameterized(String email, boolean expected) {
        boolean result = userService.isValidEmail(email);

        assertAll("Verify email validation",
                () -> assertEquals(expected, result),
                () -> assertNotNull(result)
        );
    }

    @Test
    @DisplayName("isValidEmail should return false for null email")
    void testIsValidEmailNull() {
        assertFalse(userService.isValidEmail(null));
    }

    @ParameterizedTest(name = "authenticate({0}, {1}) should be {2}")
    @CsvSource({
            "admin, 1234, true",
            "admin, wrong, false",
            "user, 1234, false",
            "user, pass, false"
    })
    @DisplayName("authenticate should validate username and password combinations")
    void testAuthenticateParameterized(String username, String password, boolean expected) {
        boolean result = userService.authenticate(username, password);

        assertAll("Verify authentication result",
                () -> assertEquals(expected, result),
                () -> assertNotNull(result)
        );
    }

    @Test
    @DisplayName("authenticate should return false for null username and password")
    void testAuthenticateNullValues() {
        assertAll("Verify null authentication inputs",
                () -> assertFalse(userService.authenticate(null, null)),
                () -> assertFalse(userService.authenticate("admin", null)),
                () -> assertFalse(userService.authenticate(null, "1234"))
        );
    }

    @Test
    @DisplayName("UserService methods should finish within timeout")
    void testTimeout() {
        assertTimeout(Duration.ofMillis(200), () -> {
            userService.isValidEmail("admin@test.com");
            userService.authenticate("admin", "1234");
        });
    }
}