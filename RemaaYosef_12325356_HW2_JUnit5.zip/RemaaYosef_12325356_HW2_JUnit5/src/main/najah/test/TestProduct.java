package main.najah.test;

import main.najah.code.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("TestProduct - JUnit 5 tests for Product")
class TestProduct {

    private Product product;

    @BeforeEach
    void setUp() {
        product = new Product("Laptop", 1000.0);
    }

    @Test
    @DisplayName("constructor should create product with valid name and price")
    void testConstructorValidInput() {
        Product p = new Product("Phone", 500.0);

        assertAll("Verify constructor values",
                () -> assertEquals("Phone", p.getName()),
                () -> assertEquals(500.0, p.getPrice()),
                () -> assertEquals(0.0, p.getDiscount())
        );
    }

    @Test
    @DisplayName("constructor should throw exception for negative price")
    void testConstructorInvalidPrice() {
        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> new Product("Invalid", -10.0)
        );

        assertEquals("Price must be non-negative", ex.getMessage());
    }

    @ParameterizedTest(name = "discount {0}% should produce final price {1}")
    @CsvSource({
            "0, 1000.0",
            "10, 900.0",
            "25, 750.0",
            "50, 500.0"
    })
    @DisplayName("applyDiscount should accept valid discount values")
    void testApplyDiscountValid(double discount, double expectedFinalPrice) {
        product.applyDiscount(discount);

        assertAll("Verify discount application",
                () -> assertEquals(discount, product.getDiscount()),
                () -> assertEquals(expectedFinalPrice, product.getFinalPrice(), 0.0001)
        );
    }

    @ParameterizedTest(name = "invalid discount {0} should throw exception")
    @CsvSource({
            "-1",
            "51",
            "100"
    })
    @DisplayName("applyDiscount should reject invalid discount values")
    void testApplyDiscountInvalid(double discount) {
        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> product.applyDiscount(discount)
        );

        assertEquals("Invalid discount", ex.getMessage());
    }

    @Test
    @DisplayName("getFinalPrice should return original price when no discount is applied")
    void testGetFinalPriceWithoutDiscount() {
        assertAll("Verify final price without discount",
                () -> assertEquals(1000.0, product.getFinalPrice(), 0.0001),
                () -> assertEquals(0.0, product.getDiscount(), 0.0001)
        );
    }

    @Test
    @DisplayName("Product operations should finish within timeout")
    void testTimeout() {
        assertTimeout(Duration.ofMillis(200), () -> {
            Product p = new Product("Monitor", 300.0);
            p.applyDiscount(20);
            p.getFinalPrice();
        });
    }
}