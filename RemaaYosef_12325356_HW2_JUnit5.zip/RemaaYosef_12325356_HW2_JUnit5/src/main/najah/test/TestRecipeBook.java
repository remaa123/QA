package main.najah.test;

import main.najah.code.Recipe;
import main.najah.code.RecipeBook;
import main.najah.code.RecipeException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.api.parallel.ExecutionMode;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("TestRecipeBook - JUnit 5 tests for RecipeBook")
@Execution(ExecutionMode.CONCURRENT)
class TestRecipeBook {

    private RecipeBook recipeBook;

    @BeforeEach
    void setUp() {
        recipeBook = new RecipeBook();
    }

    private Recipe createRecipe(String name, String price, String coffee, String milk, String sugar, String chocolate)
            throws RecipeException {
        Recipe recipe = new Recipe();
        recipe.setName(name);
        recipe.setPrice(price);
        recipe.setAmtCoffee(coffee);
        recipe.setAmtMilk(milk);
        recipe.setAmtSugar(sugar);
        recipe.setAmtChocolate(chocolate);
        return recipe;
    }

    @Test
    @DisplayName("getRecipes should return array with size 4")
    void testGetRecipes() {
        Recipe[] recipes = recipeBook.getRecipes();

        assertAll("Verify recipe array",
                () -> assertNotNull(recipes),
                () -> assertEquals(4, recipes.length)
        );
    }

    @Test
    @DisplayName("addRecipe should add a valid recipe successfully")
    void testAddRecipeValid() throws RecipeException {
        Recipe recipe = createRecipe("Latte", "20", "2", "1", "1", "0");

        boolean added = recipeBook.addRecipe(recipe);

        assertAll("Verify valid recipe addition",
                () -> assertTrue(added),
                () -> assertEquals("Latte", recipeBook.getRecipes()[0].getName())
        );
    }

    @Test
    @DisplayName("addRecipe should not add duplicate recipe")
    void testAddRecipeDuplicate() throws RecipeException {
        Recipe recipe1 = createRecipe("Mocha", "25", "2", "1", "1", "1");
        Recipe recipe2 = createRecipe("Mocha", "30", "3", "1", "2", "1");

        boolean firstAdd = recipeBook.addRecipe(recipe1);
        boolean secondAdd = recipeBook.addRecipe(recipe2);

        assertAll("Verify duplicate recipe rejection",
                () -> assertTrue(firstAdd),
                () -> assertFalse(secondAdd)
        );
    }

    @Test
    @DisplayName("addRecipe should return false when recipe book is full")
    void testAddRecipeWhenFull() throws RecipeException {
        assertTrue(recipeBook.addRecipe(createRecipe("R1", "10", "1", "1", "1", "1")));
        assertTrue(recipeBook.addRecipe(createRecipe("R2", "10", "1", "1", "1", "1")));
        assertTrue(recipeBook.addRecipe(createRecipe("R3", "10", "1", "1", "1", "1")));
        assertTrue(recipeBook.addRecipe(createRecipe("R4", "10", "1", "1", "1", "1")));

        boolean fifthAdd = recipeBook.addRecipe(createRecipe("R5", "10", "1", "1", "1", "1"));

        assertFalse(fifthAdd);
    }

    @Test
    @DisplayName("deleteRecipe should return deleted recipe name")
    void testDeleteRecipeValid() throws RecipeException {
        Recipe recipe = createRecipe("Espresso", "15", "2", "0", "0", "0");
        recipeBook.addRecipe(recipe);

        String deletedName = recipeBook.deleteRecipe(0);

        assertAll("Verify recipe deletion",
                () -> assertEquals("Espresso", deletedName),
                () -> assertEquals("", recipeBook.getRecipes()[0].getName())
        );
    }

    @Test
    @DisplayName("deleteRecipe should return null when slot is empty")
    void testDeleteRecipeInvalid() {
        String deletedName = recipeBook.deleteRecipe(0);

        assertNull(deletedName);
    }

    @Test
    @DisplayName("editRecipe should return old recipe name and replace recipe")
    void testEditRecipeValid() throws RecipeException {
        Recipe oldRecipe = createRecipe("OldCoffee", "10", "1", "1", "1", "1");
        Recipe newRecipe = createRecipe("NewCoffee", "20", "2", "2", "2", "2");
        recipeBook.addRecipe(oldRecipe);

        String editedName = recipeBook.editRecipe(0, newRecipe);

        assertAll("Verify recipe edit behavior",
                () -> assertEquals("OldCoffee", editedName),
                () -> assertEquals("", recipeBook.getRecipes()[0].getName())
        );
    }

    @Test
    @DisplayName("editRecipe should return null when trying to edit empty slot")
    void testEditRecipeInvalid() throws RecipeException {
        Recipe newRecipe = createRecipe("NewCoffee", "20", "2", "2", "2", "2");

        String editedName = recipeBook.editRecipe(0, newRecipe);

        assertNull(editedName);
    }

    @ParameterizedTest(name = "invalid recipe price input = {0}")
    @ValueSource(strings = {"-1", "abc"})
    @DisplayName("Recipe should reject invalid price input")
    void testRecipeInvalidPriceParameterized(String invalidPrice) {
        Recipe recipe = new Recipe();

        RecipeException ex = assertThrows(
                RecipeException.class,
                () -> recipe.setPrice(invalidPrice)
        );

        assertEquals("Price must be a positive integer", ex.getMessage());
    }

    @Test
    @DisplayName("RecipeBook operations should finish within timeout")
    void testTimeout() {
        assertTimeout(Duration.ofMillis(300), () -> {
            recipeBook.getRecipes();
        });
    }
}